var sideNavBar=document.querySelector(".side-navbar");

function showSideNavBar(){
    sideNavBar.style.left="0";
}

function hideSideNavBar(){
    sideNavBar.style.left="-60%";
    
}