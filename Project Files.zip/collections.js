var collectionsContainer=document.getElementById("collection");
var search=document.getElementById("search");
var collectionsList=collectionsContainer.querySelectorAll("div");

search.addEventListener("keyup",function(){

    var enteredText=event.target.value.toUpperCase();

    for(var count=0;count<collectionsList.length;count++){
        
        var collectionName=collectionsList[count].querySelector("p").textContent.toUpperCase();

        if(collectionName.indexOf(enteredText) < 0){
            collectionsList[count].style.display="none";
        }
        else{
            collectionsList[count].style.display="block";
        }
    }
})